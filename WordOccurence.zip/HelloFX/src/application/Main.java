package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Button;
import javafx.event.*;
import javafx.scene.layout.*;

import javax.swing.*;

public class Main{
	

	public static void main(String[] args) {
		
		JPanel panel = new JPanel();
		JFrame frame = new JFrame();
		frame.setSize(350,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.add(panel);
		
		panel.setLayout(null);
		
		JLabel label = new JLabel("URL");
		label.setBounds(10, 20, 80, 25);
		panel.add(label);
		
		JTextField userText = new JTextField();
		userText.setBounds(100, 20, 165, 25);
		panel.add(userText);
		
		JButton button = new JButton("Count");
		button.setBounds(10, 80, 80, 25);
		panel.add(button);
		 
		
		frame.setVisible(true);
		
}
}